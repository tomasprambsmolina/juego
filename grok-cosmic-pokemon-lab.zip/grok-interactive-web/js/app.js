/**
 * Grok's Cosmic Pokémon Lab
 * Interactive web app with PokeAPI, Drag & Drop, localStorage, particles, etc.
 * Created by Grok (xAI) — Oct 2026
 */

(() => {
  'use strict';

  // ========== DOM Elements ==========
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => document.querySelectorAll(sel);

  const searchInput = $('#search-input');
  const searchBtn = $('#search-btn');
  const pokemonGrid = $('#pokemon-grid');
  const statusMsg = $('#status-message');
  const favoritesZone = $('#favorites-zone');
  const clearFavBtn = $('#clear-favorites');
  const modal = $('#modal');
  const modalBody = $('#modal-body');
  const modalClose = $('.modal-close');
  const modalOverlay = $('.modal-overlay');
  const themeToggle = $('#theme-toggle');
  const soundToggle = $('#sound-toggle');
  const toastContainer = $('#toast-container');
  const canvas = $('#particles');
  const ctx = canvas.getContext('2d');

  // ========== State ==========
  let favorites = JSON.parse(localStorage.getItem('grok-poke-favs') || '[]');
  let currentTheme = localStorage.getItem('grok-theme') || 'dark';
  let soundEnabled = localStorage.getItem('grok-sound') !== 'false';
  let isLoading = false;
  let particles = [];
  let animationId;

  // ========== Init ==========
  function init() {
    applyTheme(currentTheme);
    updateSoundIcon();
    renderFavorites();
    setupEventListeners();
    setupParticles();
    // Load a featured Pokémon on start
    fetchPokemon('pikachu');
  }

  // ========== Theme ==========
  function applyTheme(theme) {
    currentTheme = theme;
    document.body.classList.toggle('light', theme === 'light');
    $('.theme-icon').textContent = theme === 'light' ? '☀️' : '🌙';
    localStorage.setItem('grok-theme', theme);
  }

  function toggleTheme() {
    applyTheme(currentTheme === 'dark' ? 'light' : 'dark');
    showToast(currentTheme === 'light' ? 'Tema claro activado' : 'Tema oscuro activado');
  }

  // ========== Sound (Web Audio simple beeps) ==========
  function updateSoundIcon() {
    $('.sound-icon').textContent = soundEnabled ? '🔊' : '🔇';
  }

  function toggleSound() {
    soundEnabled = !soundEnabled;
    localStorage.setItem('grok-sound', soundEnabled);
    updateSoundIcon();
    showToast(soundEnabled ? 'Sonido activado' : 'Sonido desactivado');
  }

  function playBeep(freq = 440, duration = 0.08) {
    if (!soundEnabled) return;
    try {
      const ac = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ac.createOscillator();
      const gain = ac.createGain();
      osc.connect(gain);
      gain.connect(ac.destination);
      osc.frequency.value = freq;
      osc.type = 'sine';
      gain.gain.setValueAtTime(0.12, ac.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + duration);
      osc.start();
      osc.stop(ac.currentTime + duration);
    } catch (_) {}
  }

  // ========== Particles Background ==========
  function setupParticles() {
    resizeCanvas();
    particles = Array.from({ length: 60 }, () => createParticle());
    animateParticles();
    window.addEventListener('resize', () => {
      resizeCanvas();
    });
  }

  function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }

  function createParticle() {
    return {
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      r: Math.random() * 1.8 + 0.4,
      dx: (Math.random() - 0.5) * 0.4,
      dy: (Math.random() - 0.5) * 0.4,
      alpha: Math.random() * 0.5 + 0.2
    };
  }

  function animateParticles() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const isLight = document.body.classList.contains('light');
    particles.forEach((p) => {
      p.x += p.dx;
      p.y += p.dy;
      if (p.x < 0 || p.x > canvas.width) p.dx *= -1;
      if (p.y < 0 || p.y > canvas.height) p.dy *= -1;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = isLight
        ? `rgba(124, 92, 255, ${p.alpha * 0.6})`
        : `rgba(0, 229, 255, ${p.alpha})`;
      ctx.fill();
    });
    // Draw subtle connections
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const a = particles[i];
        const b = particles[j];
        const dist = Math.hypot(a.x - b.x, a.y - b.y);
        if (dist < 100) {
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(b.x, b.y);
          ctx.strokeStyle = isLight
            ? `rgba(124, 92, 255, ${0.08 * (1 - dist / 100)})`
            : `rgba(124, 92, 255, ${0.12 * (1 - dist / 100)})`;
          ctx.lineWidth = 0.6;
          ctx.stroke();
        }
      }
    }
    animationId = requestAnimationFrame(animateParticles);
  }

  // ========== API ==========
  async function fetchPokemon(query) {
    if (isLoading) return;
    const q = String(query).trim().toLowerCase();
    if (!q) {
      showStatus('Escribe un nombre o número de Pokémon', 'error');
      return;
    }

    isLoading = true;
    showStatus('Buscando en el cosmos... 🌌', 'loading');
    pokemonGrid.innerHTML = '';

    try {
      let results = [];

      if (q === 'random') {
        // Fetch 6 random Pokémon
        const ids = Array.from({ length: 6 }, () => Math.floor(Math.random() * 898) + 1);
        const promises = ids.map((id) =>
          fetch(`https://pokeapi.co/api/v2/pokemon/${id}`).then((r) => {
            if (!r.ok) throw new Error('No encontrado');
            return r.json();
          })
        );
        results = await Promise.all(promises);
      } else {
        const res = await fetch(`https://pokeapi.co/api/v2/pokemon/${q}`);
        if (!res.ok) throw new Error('Pokémon no encontrado');
        results = [await res.json()];
      }

      showStatus('', 'success');
      statusMsg.classList.add('hidden');
      results.forEach((data) => renderCard(data));
      playBeep(520, 0.1);
    } catch (err) {
      showStatus(`Error: ${err.message}. Prueba otro nombre o número.`, 'error');
      playBeep(200, 0.15);
    } finally {
      isLoading = false;
    }
  }

  function renderCard(data) {
    const isFav = favorites.some((f) => f.id === data.id);
    const types = data.types.map((t) => t.type.name);
    const img =
      data.sprites.other?.['official-artwork']?.front_default ||
      data.sprites.front_default ||
      '';

    const card = document.createElement('article');
    card.className = 'pokemon-card';
    card.setAttribute('role', 'listitem');
    card.setAttribute('draggable', 'true');
    card.dataset.id = data.id;
    card.dataset.name = data.name;

    card.innerHTML = `
      <div class="card-shine"></div>
      <span class="card-id">#${String(data.id).padStart(3, '0')}</span>
      <button class="fav-btn ${isFav ? 'liked' : ''}" aria-label="${isFav ? 'Quitar de favoritos' : 'Añadir a favoritos'}" data-id="${data.id}">
        ${isFav ? '❤️' : '🤍'}
      </button>
      <div class="card-img-wrap">
        <img src="${img}" alt="${data.name}" loading="lazy" width="120" height="120">
      </div>
      <h3 class="card-name">${data.name}</h3>
      <div class="card-types">
        ${types.map((t) => `<span class="type-badge type-${t}">${t}</span>`).join('')}
      </div>
    `;

    // Store full data for drag
    card._pokeData = {
      id: data.id,
      name: data.name,
      img,
      types,
      stats: data.stats.map((s) => ({ name: s.stat.name, value: s.base_stat })),
      height: data.height,
      weight: data.weight
    };

    pokemonGrid.appendChild(card);
  }

  // ========== Favorites (localStorage + Drag & Drop) ==========
  function saveFavorites() {
    localStorage.setItem('grok-poke-favs', JSON.stringify(favorites));
  }

  function renderFavorites() {
    // Keep placeholder if empty
    const cards = favoritesZone.querySelectorAll('.pokemon-card');
    cards.forEach((c) => c.remove());

    if (favorites.length === 0) return;

    favorites.forEach((fav) => {
      const card = document.createElement('article');
      card.className = 'pokemon-card';
      card.setAttribute('role', 'listitem');
      card.setAttribute('draggable', 'true');
      card.dataset.id = fav.id;

      card.innerHTML = `
        <div class="card-shine"></div>
        <span class="card-id">#${String(fav.id).padStart(3, '0')}</span>
        <button class="fav-btn liked" aria-label="Quitar de favoritos" data-id="${fav.id}">❤️</button>
        <div class="card-img-wrap">
          <img src="${fav.img}" alt="${fav.name}" loading="lazy" width="100" height="100">
        </div>
        <h3 class="card-name">${fav.name}</h3>
        <div class="card-types">
          ${(fav.types || []).map((t) => `<span class="type-badge type-${t}">${t}</span>`).join('')}
        </div>
      `;
      card._pokeData = fav;
      favoritesZone.appendChild(card);
    });
  }

  function toggleFavorite(data) {
    const idx = favorites.findIndex((f) => f.id === data.id);
    if (idx >= 0) {
      favorites.splice(idx, 1);
      showToast(`${data.name} eliminado de favoritos`);
      playBeep(300, 0.1);
    } else {
      favorites.push(data);
      showToast(`${data.name} añadido a favoritos ❤️`);
      playBeep(600, 0.1);
    }
    saveFavorites();
    renderFavorites();
    // Update heart icons in main grid
    $$('.pokemon-card .fav-btn').forEach((btn) => {
      const id = Number(btn.dataset.id);
      const liked = favorites.some((f) => f.id === id);
      btn.textContent = liked ? '❤️' : '🤍';
      btn.classList.toggle('liked', liked);
      btn.setAttribute('aria-label', liked ? 'Quitar de favoritos' : 'Añadir a favoritos');
    });
  }

  function clearFavorites() {
    if (favorites.length === 0) return;
    if (!confirm('¿Seguro que quieres eliminar todos los favoritos?')) return;
    favorites = [];
    saveFavorites();
    renderFavorites();
    showToast('Favoritos eliminados');
    // Reset hearts
    $$('.fav-btn').forEach((btn) => {
      btn.textContent = '🤍';
      btn.classList.remove('liked');
    });
  }

  // ========== Modal ==========
  function openModal(data) {
    const maxStat = Math.max(...data.stats.map((s) => s.value), 100);
    modalBody.innerHTML = `
      <div class="modal-pokemon">
        <img src="${data.img}" alt="${data.name}">
        <h2 id="modal-title">${data.name}</h2>
        <p style="color:var(--text-muted);margin-bottom:0.5rem">#${String(data.id).padStart(3, '0')}</p>
        <div class="card-types" style="justify-content:center;margin-bottom:0.75rem">
          ${(data.types || []).map((t) => `<span class="type-badge type-${t}">${t}</span>`).join('')}
        </div>
        <p style="font-size:0.9rem;color:var(--text-secondary)">
          Altura: ${(data.height / 10).toFixed(1)} m · Peso: ${(data.weight / 10).toFixed(1)} kg
        </p>
        <div class="modal-stats">
          ${data.stats
            .map(
              (s) => `
            <div class="stat-row">
              <span class="stat-label">${s.name.replace('-', ' ')}</span>
              <div class="stat-bar">
                <div class="stat-fill" style="width:0%" data-width="${(s.value / maxStat) * 100}"></div>
              </div>
              <span class="stat-value">${s.value}</span>
            </div>
          `
            )
            .join('')}
        </div>
      </div>
    `;
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
    // Animate bars
    requestAnimationFrame(() => {
      $$('.stat-fill').forEach((el) => {
        el.style.width = el.dataset.width + '%';
      });
    });
    playBeep(480, 0.08);
  }

  function closeModal() {
    modal.classList.add('hidden');
    document.body.style.overflow = '';
  }

  // ========== UI Helpers ==========
  function showStatus(msg, type) {
    if (!msg) {
      statusMsg.classList.add('hidden');
      return;
    }
    statusMsg.textContent = msg;
    statusMsg.className = `status-message ${type}`;
    statusMsg.classList.remove('hidden');
  }

  function showToast(msg) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = msg;
    toastContainer.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
  }

  function switchSection(sectionId) {
    $$('.section').forEach((s) => s.classList.remove('active'));
    $$('.nav-btn').forEach((b) => b.classList.remove('active'));
    const section = $(`#${sectionId}`);
    const btn = $(`.nav-btn[data-section="${sectionId}"]`);
    if (section) section.classList.add('active');
    if (btn) btn.classList.add('active');
    playBeep(400, 0.06);
  }

  // ========== Event Listeners ==========
  function setupEventListeners() {
    // Search
    searchBtn.addEventListener('click', () => fetchPokemon(searchInput.value));
    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        fetchPokemon(searchInput.value);
      }
      if (e.key === 'Escape') {
        searchInput.value = '';
        searchInput.blur();
      }
    });

    // Hints
    $$('.hint').forEach((h) => {
      h.addEventListener('click', () => {
        const q = h.dataset.query;
        searchInput.value = q === 'random' ? '' : q;
        fetchPokemon(q);
      });
      h.setAttribute('tabindex', '0');
      h.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          h.click();
        }
      });
    });

    // Navigation
    $$('.nav-btn').forEach((btn) => {
      btn.addEventListener('click', () => switchSection(btn.dataset.section));
    });

    // Logo home
    $('.logo').addEventListener('click', () => switchSection('explorer'));
    $('.logo').addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        switchSection('explorer');
      }
    });

    // Theme & Sound
    themeToggle.addEventListener('click', toggleTheme);
    soundToggle.addEventListener('click', toggleSound);

    // Clear favorites
    clearFavBtn.addEventListener('click', clearFavorites);

    // Modal close
    modalClose.addEventListener('click', closeModal);
    modalOverlay.addEventListener('click', closeModal);
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && !modal.classList.contains('hidden')) {
        closeModal();
      }
    });

    // Delegation for cards (fav + click + drag)
    document.addEventListener('click', (e) => {
      const favBtn = e.target.closest('.fav-btn');
      if (favBtn) {
        e.stopPropagation();
        const card = favBtn.closest('.pokemon-card');
        if (card && card._pokeData) {
          toggleFavorite(card._pokeData);
        }
        return;
      }

      const card = e.target.closest('.pokemon-card');
      if (card && card._pokeData && !e.target.closest('.fav-btn')) {
        openModal(card._pokeData);
      }
    });

    // Drag & Drop
    document.addEventListener('dragstart', (e) => {
      const card = e.target.closest('.pokemon-card');
      if (!card || !card._pokeData) return;
      card.classList.add('dragging');
      e.dataTransfer.setData('text/plain', JSON.stringify(card._pokeData));
      e.dataTransfer.effectAllowed = 'copy';
      playBeep(350, 0.05);
    });

    document.addEventListener('dragend', (e) => {
      const card = e.target.closest('.pokemon-card');
      if (card) card.classList.remove('dragging');
    });

    favoritesZone.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
      favoritesZone.classList.add('drag-over');
    });

    favoritesZone.addEventListener('dragleave', (e) => {
      if (!favoritesZone.contains(e.relatedTarget)) {
        favoritesZone.classList.remove('drag-over');
      }
    });

    favoritesZone.addEventListener('drop', (e) => {
      e.preventDefault();
      favoritesZone.classList.remove('drag-over');
      try {
        const data = JSON.parse(e.dataTransfer.getData('text/plain'));
        if (data && data.id) {
          if (!favorites.some((f) => f.id === data.id)) {
            toggleFavorite(data);
          } else {
            showToast('Ya está en favoritos');
          }
        }
      } catch (_) {}
    });

    // Keyboard navigation for grid (basic arrow support when focused)
    pokemonGrid.addEventListener('keydown', (e) => {
      // Future enhancement possible
    });
  }

  // ========== Start ==========
  init();
})();
