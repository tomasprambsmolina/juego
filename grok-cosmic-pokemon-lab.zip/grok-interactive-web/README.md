# 🌌 Grok's Cosmic Pokémon Lab

**Página web interactiva, visualmente atractiva y funcional** creada por **Grok (xAI)**.

## ✨ Características

### Interactividad
- Eventos de clic, teclado (Enter, Escape)
- **Drag & Drop** nativo para añadir Pokémon a favoritos
- Validaciones de búsqueda
- Lógica dinámica con estados de carga, error y éxito
- Modal con estadísticas animadas
- Toggle de tema claro/oscuro
- Sonidos sutiles (Web Audio API) con control on/off

### Estilo avanzado
- **CSS Grid + Flexbox** para layouts modernos
- Animaciones `@keyframes` (float, shimmer, cardIn, modalIn, heartPop, toast...)
- Transiciones suaves en hover y focus
- **Diseño 100% responsivo** con media queries
- Glassmorphism + partículas animadas en canvas
- Gradientes dinámicos y tipografía Orbitron + Inter
- Soporte para `prefers-reduced-motion`

### API externa
- **PokeAPI** (https://pokeapi.co) — gratuita, sin API key
- Búsqueda por nombre o número
- Botón "Aleatorio" que carga 6 Pokémon al azar
- Caché de favoritos en `localStorage`

### Persistencia
- Favoritos guardados automáticamente
- Preferencia de tema y sonido persistentes

### Accesibilidad
- Roles ARIA, labels, `aria-live`
- Navegación por teclado
- Contraste adecuado

## 🚀 Cómo usar

1. Abre `index.html` en cualquier navegador moderno (o usa un servidor local).
2. Busca un Pokémon (ej: `pikachu`, `25`, `charizard`).
3. Haz clic en una carta para ver detalles y estadísticas.
4. Arrastra cartas a la zona de **Favoritos** o haz clic en el corazón ❤️.
5. Cambia de tema y activa/desactiva el sonido.

## 📁 Estructura

```
grok-interactive-web/
├── index.html
├── css/
│   └── styles.css
├── js/
│   └── app.js
└── README.md
```

## 🌐 Despliegue en GitHub Pages

1. Crea un repositorio nuevo en GitHub (ej: `grok-cosmic-pokemon-lab`).
2. Sube estos archivos (puedes usar GitHub Desktop, o la interfaz web, o `git`).
3. Ve a **Settings → Pages**.
4. En "Source" selecciona la rama `main` (o `master`) y carpeta `/ (root)`.
5. Guarda. En unos minutos tendrás tu sitio en:
   `https://TU-USUARIO.github.io/NOMBRE-DEL-REPO/`

### Comandos rápidos (si usas terminal)

```bash
git init
git add .
git commit -m "🌌 Grok's Cosmic Pokémon Lab - Interactive web project"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/TU-REPO.git
git push -u origin main
```

## 🛠️ Tecnologías

- HTML5 semántico
- CSS3 (Grid, Flexbox, Custom Properties, Animations, Media Queries)
- JavaScript Vanilla (ES6+, Fetch API, Drag & Drop API, localStorage, Canvas, Web Audio)
- PokeAPI
- Google Fonts

## 🎨 Personalización

- Colores en `:root` de `styles.css`
- Nombre del proyecto en el header y título
- Puedes cambiar la API o añadir más endpoints fácilmente

---

**Creado con 💜 por Grok (xAI)** · Octubre 2026  
Inspirado en el universo, la curiosidad y el aprendizaje interactivo.
